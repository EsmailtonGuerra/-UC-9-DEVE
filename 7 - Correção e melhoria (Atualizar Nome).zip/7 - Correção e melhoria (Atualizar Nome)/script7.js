// Função chamada ao clicar no botão "Atualizar"
function atualizarNome() {
  // Obtém o texto digitado no campo de entrada
  let nome = document.getElementById("novoNome").value;

  // Atualiza o parágrafo com o novo nome
  document.getElementById("resultado").textContent = "Nome atual: " + nome;
}
