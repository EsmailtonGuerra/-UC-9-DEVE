// Função chamada ao clicar no botão
function mudarCor() {
  // Obtém o valor da cor selecionada no menu
  const cor = document.getElementById("corSelecionada").value;

  // Aplica a cor ao texto com o id 'texto'
  document.getElementById("texto").style.color = cor;
}
